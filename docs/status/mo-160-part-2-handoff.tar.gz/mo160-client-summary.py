import collections
import importlib.metadata
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, '/tmp/mo160-client-deps')
from jsonschema import Draft202012Validator

root = Path('/tmp')
requests = [json.loads(s) for s in (root / 'mo160-client-requests.jsonl').read_text().splitlines()]
responses = [json.loads(s) for s in (root / 'mo160-client-responses.jsonl').read_text().splitlines()]
cli = [json.loads(s) for s in (root / 'mo160-client-cli.jsonl').read_text().splitlines()]
amp_phases = ['doctor', 'tools-list', 'svc-add', 'svc-add-debug']
phases = list(dict.fromkeys(r['phase'] for r in requests))
counts = {}
for phase in phases:
    counts[phase] = dict(collections.Counter(
        row['body']['method'] for row in requests if row['phase'] == phase))
amp_requests = [r for r in requests if r['phase'] in amp_phases]
amp_counts = dict(collections.Counter(row['body']['method'] for row in amp_requests))
assert amp_counts == {'initialize': 4, 'notifications/initialized': 4, 'tools/list': 4}
assert all(item['returncode'] == 0 for item in cli if item['phase'] in ['doctor', 'tools-list'])
assert all(item['returncode'] == 1 for item in cli if item['phase'].startswith('svc-'))
assert 'amp svc is not enabled for your account.' in cli[-1]['stderr']
initializes = [r for r in amp_requests if r['body']['method'] == 'initialize']
assert all(r['value_nodes'] == 14 and r['nodes_with_keys'] == 26 and r['bytes'] == 254
           for r in initializes)
catalogs = [r['body']['result']['tools'] for r in responses
            if r['request_method'] == 'tools/list' and r['status'] == 200]
assert len(catalogs) == 5
assert all(catalog == catalogs[0] for catalog in catalogs)
tools = {tool['name']: tool for tool in catalogs[0]}
assert set(tools) == {'add', 'read', 'reject', 'fail'}
for tool in tools.values():
    Draft202012Validator.check_schema(tool['inputSchema'])
    Draft202012Validator.check_schema(tool['outputSchema'])
calls = []
for row in responses:
    if row['request_method'] != 'tools/call':
        continue
    matching = [r for r in requests if r['phase'] == row['phase']
                and r['body'].get('id') == row['request_id']]
    assert len(matching) == 1
    request = matching[0]['body']
    assert row['phase'].startswith('python-control')
    assert row['status'] == 200
    result = row['body']['result']
    name = request['params']['name']
    Draft202012Validator(tools[name]['inputSchema']).validate(request['params']['arguments'])
    Draft202012Validator(tools[name]['outputSchema']).validate(result['structuredContent'])
    text = ''.join(block['text'] for block in result['content'] if block['type'] == 'text')
    assert json.loads(text) == result['structuredContent']
    calls.append({'phase': row['phase'], 'tool': name, 'result': result,
                  'input_valid': True, 'structuredContent_valid': True,
                  'text_matches_structuredContent': True})
assert [c['tool'] for c in calls] == ['read', 'add', 'read', 'reject', 'fail', 'read']
assert [c['result']['structuredContent']['value'] for c in calls[:3]] == ['0', '7', '7']
assert calls[3]['result']['isError'] is True
assert calls[3]['result']['structuredContent'] == {'error': {'kind': 'application', 'value': 'denied'}}
assert calls[4]['result']['isError'] is True
assert calls[4]['result']['structuredContent'] == {'error': {
    'kind': 'runtime', 'code': 'handler_failed',
    'message': 'the tool handler failed; service state is unchanged', 'effect': 'none'}}
assert 'canary' not in json.dumps(calls[4]['result'])
assert calls[5]['result']['structuredContent'] == {'value': '7'}
token = (root / 'mo160-live-token').read_bytes().strip()
scanned = []
for path in sorted(root.glob('mo160-client-*')):
    if path.is_file():
        assert token not in path.read_bytes(), f'secret found in scratch file {path.name}'
        scanned.append(str(path))
assert not (root / 'mo160-client-settings.json').exists()
summary = {
    'amp_cli_version': subprocess.check_output(['amp', '--version'], text=True).strip(),
    'native_authority': '127.0.0.1:' + (root / 'mo160-live-port').read_text().strip(),
    'proxy_authority': '127.0.0.1:' + (root / 'mo160-client-proxy-port').read_text().strip(),
    'amp_clientInfo': initializes[0]['body']['params']['clientInfo'],
    'amp_protocolVersion': initializes[0]['body']['params']['protocolVersion'],
    'amp_initialize_body': initializes[0]['body'],
    'amp_initialize_bytes': 254,
    'amp_initialize_nodes_native_semantics': 14,
    'amp_initialize_nodes_including_keys': 26,
    'node_definition': 'Each JSON object/array/scalar is one node; keys excluded, matching runtime/mcp-transport.mo:118-132.',
    'counts_by_phase': counts,
    'real_amp_total_counts': {**amp_counts, 'tools/call': 0},
    'passing_doctor_tools_list_counts': {'initialize': 2, 'notifications/initialized': 2,
                                       'tools/list': 2, 'tools/call': 0},
    'amp_doctor_output': cli[0]['stdout'],
    'amp_catalog_tools': [item for item in json.loads(cli[1]['stdout'])
                          if item['name'].startswith('mcp__mo160__')],
    'amp_svc_debug_failure': cli[-1]['stderr'],
    'amp_get_stream_statuses': [r['status'] for r in responses
                              if r['phase'] in amp_phases and r['http_method'] == 'GET'],
    'schema_validator': 'jsonschema ' + importlib.metadata.version('jsonschema') + ' Draft202012Validator',
    'catalogs_identical': len(catalogs),
    'unique_input_output_schemas_validated': 8,
    'NOT_AMP_python_fullstack_calls_validated': calls,
    'initial_control_script_error': 'Incorrect scratch assertion expected stopped for handler stop; response was handler_failed. Confirmed mapping/test, corrected scratch assertion, completed read recovery without repeating add.',
    'all_evidence_files_scanned_secret_free': scanned,
    'transient_secret_settings_deleted': True,
    'claude_code': 'Not installed; not installed for this run; no Claude Code interoperability claim.'}
(root / 'mo160-client-summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
