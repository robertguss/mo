#!/usr/bin/env bash
set -euo pipefail
export MO_INTEROP_TOKEN
MO_INTEROP_TOKEN=$(cat /tmp/mo160-live-token)
exec /tmp/mo160-live
