#!/usr/bin/env bash
set -u
set -o pipefail
root=/home/user/workspace/repo
build=build/mo160-o2
debug='-O2 -g -pthread'
snapshot() {
    sha256sum /tmp/mo160-headroom.c /tmp/mo160-headroom-run.sh "$root/Makefile" \
        "$root/tests/service_compile.h" "$root/tests/program_fixture.h" || return $?
    find "$root/src" "$root/runtime" "$root/lib" -type f -print0 | sort -z | xargs -0 sha256sum
}
{
    date -u '+%Y-%m-%dT%H:%M:%SZ'
    git -C "$root" rev-parse HEAD
    gcc --version
    printf 'CC=gcc BUILD=%s DEBUG=%s\n' "$build" "$debug"
} > /tmp/mo160-headroom-metadata.txt || exit $?
snapshot > /tmp/mo160-headroom-sources-before.sha256 || exit $?
make -C "$root" -j8 CC=gcc BUILD="$build" DEBUG="$debug" \
    "$build/debug/tests/test_protocol_server.test" > /tmp/mo160-headroom-build-final.log 2>&1 || exit $?
mapfile -t objects < <(find "$root/$build/debug/src" -name '*.o' ! -path '*/main.o' | sort)
gcc -std=c17 -O2 -g -pthread -Wall -Wextra -Werror -I"$root/src" -I"$root/tests" \
    -I"$root/build/generated" -I"$root/vendor/sqlite" /tmp/mo160-headroom.c \
    "${objects[@]}" "$root/$build/debug/vendor/sqlite/sqlite3.o" \
    -Wl,--wrap=mo_call -Wl,--wrap=mo_service_step -Wl,--wrap=mo_arena_init_confidential \
    -Wl,--wrap=mo_arena_allocate -Wl,--wrap=mo_process_new -Wl,--wrap=mo_process_free \
    -lm -o /tmp/mo160-headroom || exit $?
"$root/$build/debug/tests/test_protocol_server.test" > /tmp/mo160-headroom-server-test.log 2>&1 || exit $?
status=0
for mode in matrix catalog0 catalog1 catalog7 catalog2 catalog5 catalog3 catalog4 catalog6; do
    args=()
    [[ $mode == matrix ]] || args+=("$mode")
    /tmp/mo160-headroom "${args[@]}" > "/tmp/mo160-headroom-$mode.tsv" 2> "/tmp/mo160-headroom-$mode.log"
    code=$?
    printf '%s exit=%s\n' "$mode" "$code"
    (( code == 0 )) || status=1
done
snapshot > /tmp/mo160-headroom-sources-after.sha256 || exit $?
if ! cmp -s /tmp/mo160-headroom-sources-before.sha256 /tmp/mo160-headroom-sources-after.sha256; then
    printf '%s\n' 'FAIL sources changed during measurement; evidence is not a single source snapshot.' >&2
    status=1
fi
exit "$status"
