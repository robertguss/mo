#define _POSIX_C_SOURCE 200809L
#include "base/stack.h"
#include "service_compile.h"
#include "tools/protocol.h"
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static volatile sig_atomic_t stopped;

static void stop(int sig) {
  (void)sig;
  stopped = 1;
}

static void run(void *unused) {
  (void)unused;
  const char source[] =
      "module Main\nservice\nstate Int = 0\ntools add, read, reject, fail\n"
      "token from env \"MO_INTEROP_TOKEN\"\nend\n"
      "fn add(state: Int, _now: Time, amount: Int) : (Int, Int)\n"
      "(state + amount, state + amount)\nend\n"
      "fn read(state: Int, _now: Time) : Text\nstate.to_text\nend\n"
      "fn reject(_state: Int, _now: Time) : Result(Text, "
      "Text)\nError(\"denied\")\nend\n"
      "fn fail(_state: Int, _now: Time) : Text\nstop \"canary must not leave "
      "server\"\nend\n";
  struct mo_image *image = compile(source);
  struct mo_listener *listener;
  struct mo_listener_config config = {.port = 0};
  MO_ASSERT(mo_listener_open(&config, "MO_INTEROP_TOKEN", &listener) ==
            MO_LISTENER_OK);
  unsigned port = mo_listener_port(listener);
  char authority[64];
  int n = snprintf(authority, sizeof authority, "127.0.0.1:%u", port);
  MO_ASSERT(n > 0 && (size_t)n < sizeof authority);
  const char *authorities[] = {authority};
  struct mo_store *store;
  MO_ASSERT(mo_store_open(NULL, &store) == MO_STORE_OK);
  struct mo_protocol_server *server;
  MO_ASSERT(mo_protocol_server_new(image, 0, store, listener, authorities, 1,
                                   &server) == MO_PROTOCOL_SERVER_OK);
  FILE *file = fopen("/tmp/mo160-live-port", "w");
  MO_ASSERT(file != NULL && fprintf(file, "%u\n", port) > 0 &&
            fclose(file) == 0);
  puts("MO160 native loopback ready");
  fflush(stdout);
  while (!stopped) {
    union mo_listener_result result;
    MO_ASSERT(mo_listener_call(listener, MO_LISTENER_NOW, NULL, &result) ==
              MO_LISTENER_OK);
    MO_ASSERT(
        mo_protocol_server_poll(server, result.now.monotonic_us + 100000) ==
        MO_PROTOCOL_SERVER_OK);
  }
  mo_protocol_server_free(server);
  mo_listener_close(listener);
  mo_store_close(store);
  mo_image_free(image);
}

int main(void) {
  MO_ASSERT(signal(SIGTERM, stop) != SIG_ERR);
  MO_ASSERT(signal(SIGINT, stop) != SIG_ERR);
  MO_ASSERT(mo_with_stack(MO_SOURCE_STACK_SIZE, run, NULL) == 0);
  return 0;
}
