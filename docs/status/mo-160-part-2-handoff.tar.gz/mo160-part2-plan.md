# MO-160 part 2 execution plan

Base: b119a45cb559ac3508cd5b540984165846313fbc, the verified squash merge of #261.
Branch: mo-160-part-2. The part-1 branch remains unchanged.

## Behaviour

A C embedding can expose an initialized Mo service to real MCP clients over
plain HTTP/1.1 without adding `mo serve`, another CLI command, or a public Mo
network capability. `mo check` reports E0105 and E0106 with D328's exact text.

## Contract

Reference section 11.5, services design section 9, implementation's five
conditions, D316 to D322 and D324 to D329. The latest explicit decisions govern
the gaps left in the part-1 documents. Item 1 is already merged.

Precedent: 7c22cca5, MO-158's runtime-owned STOREOP family, host/host.h and
host/store.c, service integration, compile-time fault tests, fuzz corpus,
library-map narrative and saved-state ownership documentation.

## Workflow

1. Ground: done. Two read-only explorers mapped host operations, private protocol
   ABI, callback lifetimes and accounting. Baseline host/lowering checks passed.
2. Sketch: done. Independent native-state and Mo-reducer candidates produced.
3. Cross-judge and choose the bounded listener architecture.
4. Implement and verify native real/fake listener effects and Mo HTTP policy,
   framing, authentication, authority and lifecycle before RPC dispatch.
5. Integrate initialize/list/call, fixed errors and allocation-independent
   fallbacks. Verify callback retention, disconnects and persistence.
6. Add E0105/E0106 fixtures and exact diagnostic wording.
7. Extend the existing HTTP and RPC fuzz targets and corpora for the new paths.
8. Measure the complete D329 matrix on gcc -O2. Record instructions, protocol
   heap, native bytes and wall time. Lower byte ceilings only if required.
9. Exercise Claude Code and Amp as clients. Record initialize node counts and
   initialize/list/call outcomes, or the exact environment limitation.
10. Run all six CI=1 groups and fuzz smoke on the final tree. Publish draft PR(s)
    with each check result and measurement. Obtain fresh independent whole-diff
    review threads, fix actionable findings and rerun affected checks.
11. Report PR heads, evidence, findings and remaining decisions. Do not merge.

## Throughput checkpoint

- Blocking first steps: recover approved numerical contracts, validate base,
  choose lifecycle ownership, add aggregate accounting before authenticated data.
- Independent workstreams: native host effects and pure Mo HTTP policy use
  disjoint files after the shared API is fixed. RPC follows their verification.
- Shared mutable state: one owner edits the private ABI, limits and Makefile.
  Each connection owns its buffers/process; the adapter alone steps the service.
- Smallest safe decomposition: one implementation owner here, bounded helpers
  for isolated host/policy pieces, and independent fresh-thread PR reviewers.

## Data shape and alternatives

Candidate A keeps eight explicit native connection states and pure Mo HTTP
decisions. Candidate B moves lifecycle transitions into a Mo event/action reducer.
Both retain one native listener family and existing service admission APIs.
Rubric: approved boundary, aggregate budgets, callback/disconnect lifetimes,
private ABI size/invariant ownership, and incremental verification.
Final selection follows the independent cross-judge, without a human gate.

## Files and ownership

- src/base/hostops.def: runtime-only LISTENEROP inventory, ignored by existing readers.
- src/base/limits.h: names for approved targets only.
- src/host/host.h and listener implementation: numeric bind, descriptors,
  readiness, partial I/O, clocks, native credentials, real/fake parity.
- src/vm/vm.h, internal.h, process.c and heap accounting: cumulative instruction
  observation and combined confidential stack/native/heap request accounting.
- runtime/http.mo: syntax, authority, policy, framing and HTTP response plans.
- runtime/mcp-rpc.mo: D325 texts, exact postparse D326 node admission.
- runtime/mcp.mo: runtime tool-result constructors and complete fallback templates.
- src/tools/protocol.h/c: checked private ABI and adapter-facing entry points.
- src/tools protocol adapter files: connection ownership, service hooks, catalog,
  token-wide rate, budgets, delayed serialization and close/drain lifecycle.
- src/check/services.c and codes/diagnostic owners: D328 checker refusals.
- Existing tests/runtime fixtures, tests/errors cases and targeted C integration
  tests: exact public results, negative controls and meaningful boundaries.
- Existing fuzz/fuzz_http.c and fuzz/fuzz_mcp_rpc.c plus seeds: new input paths.
- Measurement/client drivers: rerunnable end-to-end artifact and limit matrix.
- Makefile: embedding, fault substitutions and executable harnesses as needed.
- docs/agent-guide.md, docs/reference/README.md, docs/design/services.md,
  docs/design/library.md and LEARNINGS.md: actual behaviour and ownership.

No Mo Core, bytecode or primitive contract changes are planned. Every hostops
reader must continue ignoring LISTENEROP. Private embedded ABI additions update
the Mo producer, structural validator, C consumer and ABI refusal tests together.

## Verification contract

Tests assert exact wire results and state effects through public C/Mo boundaries.
Observe failures before implementation or use compiling semantic mutants.
Cover header/body fragmentation, auth-before-framing, secret canary exclusion,
same 401 variants, authority statuses, CL/TE/chunks/trailers, notifications,
node and depth boundaries, known-call rate consumption, postadmission failures,
disconnect without replay, eight concurrent peers and cleanup/wiping.

The gate is CI=1 bash ci/check.sh gcc clang sanitize drivers static lean,
plus make fuzz-smoke. A skip is not a pass. Final review is independent of
authorship and covers the entire PR, not only individual pieces.

Open product questions: none currently identified. No invented listener-count,
backlog, polling-period or new resource ceilings. Implementation choices are
reversible and remain inside the approved budgets.
