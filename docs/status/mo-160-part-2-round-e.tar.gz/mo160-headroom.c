#define _POSIX_C_SOURCE 200809L
#include "base/stack.h"
#include "service_compile.h"
#include "tools/protocol.h"
#include <inttypes.h>
#include <stdarg.h>
#include <time.h>

static unsigned failures, headroom_failures;
static char token[257];
static bool measuring;
static uint64_t measured_stage_us;
static bool concurrent_watch;
static struct mo_process *concurrent_processes[8];
static size_t concurrent_process_count;
static struct {
    bool active, heap_seen, prepare_seen, prepare_none;
    struct mo_arena *arena;
    struct mo_process *process;
    const struct mo_image *image;
    enum mo_outcome prepare_outcome;
    size_t arena_limit, arena_used, heap_allowance;
    uint64_t prepare_work, prepare_us, stage_us;
} startup_bounds;
void __real_mo_arena_init_confidential(struct mo_arena *, size_t);
void __wrap_mo_arena_init_confidential(struct mo_arena *, size_t);
void *__real_mo_arena_allocate(struct mo_arena *, size_t, size_t);
void *__wrap_mo_arena_allocate(struct mo_arena *, size_t, size_t);
struct mo_process *__real_mo_process_new(const struct mo_image *, const struct mo_limits *);
struct mo_process *__wrap_mo_process_new(const struct mo_image *, const struct mo_limits *);
void __real_mo_process_free(struct mo_process *);
void __wrap_mo_process_free(struct mo_process *);
void __wrap_mo_arena_init_confidential(struct mo_arena *arena, size_t limit) {
    if (startup_bounds.active && startup_bounds.arena == NULL && limit == MO_LIMIT_MCP_CATALOG_MEMORY) {
        startup_bounds.arena = arena;
        startup_bounds.arena_limit = limit;
    }
    __real_mo_arena_init_confidential(arena, limit);
}
void *__wrap_mo_arena_allocate(struct mo_arena *arena, size_t size, size_t alignment) {
    void *result = __real_mo_arena_allocate(arena, size, alignment);
    if (startup_bounds.active && arena == startup_bounds.arena) startup_bounds.arena_used = arena->used;
    return result;
}
struct mo_process *__wrap_mo_process_new(const struct mo_image *image, const struct mo_limits *limits) {
    bool catalog = startup_bounds.active && startup_bounds.arena_used != 0 && !startup_bounds.heap_seen &&
        limits->heap_size <= MO_LIMIT_MCP_CATALOG_MEMORY - startup_bounds.arena_used;
    if (catalog) {
        startup_bounds.heap_seen = true;
        startup_bounds.heap_allowance = limits->heap_size;
    }
    struct mo_process *result = __real_mo_process_new(image, limits);
    if (catalog) { startup_bounds.process = result; startup_bounds.image = image; }
    if (concurrent_watch && result != NULL && limits->heap_size > MO_LIMIT_MCP_HEADER_HEAP &&
        limits->heap_size <= MO_LIMIT_MCP_REQUEST_MEMORY) {
        MO_ASSERT(concurrent_process_count < 8);
        concurrent_processes[concurrent_process_count++] = result;
    }
    return result;
}
void __wrap_mo_process_free(struct mo_process *process) {
    if (concurrent_watch)
        for (size_t i = 0; i < concurrent_process_count; i++)
            if (concurrent_processes[i] == process) concurrent_processes[i] = NULL;
    __real_mo_process_free(process);
}
static const char source[] =
    "module Main\n"
    "enum Chain\nDone\nNext(Chain)\nend\n"
    "service\nstate Int = 0\ntools read, listints, setints, mapints, text, chain, response, many, escaped\n"
    "token from env \"MO_HEADROOM_TOKEN\"\nend\n"
    "fn read(state: Int, _now: Time) : Text\nstate.to_text\nend\n"
    "fn listints(state: Int, _now: Time, value: List(Int)) : (Int, Int)\n"
    "(state + 1, value.size)\nend\n"
    "fn setints(state: Int, _now: Time, value: Set(Int)) : (Int, Int)\n"
    "(state + 1, value.size)\nend\n"
    "fn mapints(state: Int, _now: Time, value: Map(Int, List(Int))) : (Int, Int)\n"
    "(state + 1, value.size)\nend\n"
    "fn text(state: Int, _now: Time, value: Text) : (Int, Int)\n"
    "(state + 1, value.byte_count)\nend\n"
    "fn chain(state: Int, _now: Time, _value: Chain) : (Int, Int)\n(state + 1, state + 1)\nend\n"
    "fn response(state: Int, _now: Time, size: Int) : (Int, Text)\n"
    "(state + 1, \"x\".repeat(size))\nend\n"
    "fn escaped(state: Int, _now: Time, size: Int) : (Int, Text)\n"
    "(state + 1, \"\\u{0}\".repeat(size))\nend\n"
    "fn many(state: Int, _now: Time, size: Int) : (Int, List(Int))\n"
    "var values = []\nfor _i in 0..size\nvalues = values.append(0)\nend\n"
    "(state + 1, values)\nend\n";

static void need(bool yes, const char *what) {
    if (!yes) { fprintf(stderr, "FAIL %s\n", what); failures++; }
}
static uint64_t now_us(void) {
    struct timespec ts;
    MO_ASSERT(clock_gettime(CLOCK_MONOTONIC, &ts) == 0);
    return (uint64_t)ts.tv_sec * UINT64_C(1000000) + (uint64_t)ts.tv_nsec / 1000;
}
enum mo_outcome __real_mo_call(struct mo_process *, uint32_t, const struct mo_cell *, uint32_t,
                              struct mo_cell *, struct mo_defect *);
enum mo_outcome __wrap_mo_call(struct mo_process *, uint32_t, const struct mo_cell *, uint32_t,
                              struct mo_cell *, struct mo_defect *);
bool __real_mo_service_step(struct mo_service_loop *);
bool __wrap_mo_service_step(struct mo_service_loop *);
enum mo_outcome __wrap_mo_call(struct mo_process *p, uint32_t function,
                              const struct mo_cell *args, uint32_t count,
                              struct mo_cell *out, struct mo_defect *defect) {
    bool startup = startup_bounds.active && p == startup_bounds.process;
    uint64_t instructions = startup ? mo_process_instructions_remaining(p) : 0;
    uint64_t before = now_us();
    enum mo_outcome result = __real_mo_call(p, function, args, count, out, defect);
    uint64_t elapsed = now_us() - before;
    if (measuring && elapsed > measured_stage_us) measured_stage_us = elapsed;
    if (startup) {
        if (elapsed > startup_bounds.stage_us) startup_bounds.stage_us = elapsed;
        const struct mo_bytecode *file = mo_image_bytecode(startup_bounds.image);
        const struct mo_bytecode_string *name = &file->strings[file->functions[function].name];
        if (name->length == strlen("Mcp.prepare") && memcmp(name->bytes, "Mcp.prepare", name->length) == 0) {
            startup_bounds.prepare_seen = true; startup_bounds.prepare_outcome = result;
            startup_bounds.prepare_none = result == MO_RETURNED && mo_cell_get_tag(*out) == 0;
            startup_bounds.prepare_work = instructions - mo_process_instructions_remaining(p);
            startup_bounds.prepare_us = elapsed;
        }
    }
    return result;
}
bool __wrap_mo_service_step(struct mo_service_loop *service) {
    uint64_t before = now_us(); bool result = __real_mo_service_step(service);
    uint64_t elapsed = now_us() - before;
    if (measuring && elapsed > measured_stage_us) measured_stage_us = elapsed;
    return result;
}
static void add(struct mo_buffer *b, const char *text) {
    MO_ASSERT(mo_buffer_append_text(b, text));
}
static void fmt(struct mo_buffer *b, const char *format, ...) {
    char text[1024]; va_list args;
    va_start(args, format); int n = vsnprintf(text, sizeof text, format, args); va_end(args);
    MO_ASSERT(n >= 0 && (size_t)n < sizeof text); add(b, text);
}
static void repeat(struct mo_buffer *b, const char *text, size_t count) {
    for (size_t i = 0; i < count; i++) add(b, text);
}
static struct mo_buffer buffer(void) {
    struct mo_buffer b; mo_buffer_init(&b, 8 << 20); return b;
}
static struct mo_buffer call_start(const char *name, const char *arg) {
    struct mo_buffer b = buffer();
    fmt(&b, "{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"tools/call\",\"params\":{\"name\":\"%s\",\"arguments\":{\"%s\":", name, arg);
    return b;
}
static void call_end(struct mo_buffer *b) { add(b, "}}}"); }
static struct mo_buffer scalar_call(const char *name, size_t n) {
    struct mo_buffer b = call_start(name, "size"); fmt(&b, "\"%zu\"", n); call_end(&b); return b;
}
static struct mo_buffer plain(const char *text) { struct mo_buffer b = buffer(); add(&b, text); return b; }

struct fixture_server {
    struct mo_image *image;
    struct mo_store *store;
    struct mo_listener *listener;
    struct mo_protocol_server *server;
};
static bool start(struct fixture_server *f, struct mo_image *image, const char *label) {
    *f = (struct fixture_server){.image = image};
    MO_ASSERT(mo_listener_fake("MO_HEADROOM_TOKEN", &f->listener) == MO_LISTENER_OK);
    MO_ASSERT(mo_store_open(NULL, &f->store) == MO_STORE_OK);
    const char *authorities[] = {"localhost"}; uint64_t before = now_us();
    memset(&startup_bounds, 0, sizeof startup_bounds); startup_bounds.active = true;
    enum mo_protocol_server_status status = mo_protocol_server_new(image, 0, f->store, f->listener, authorities, 1, &f->server);
    startup_bounds.active = false;
    fprintf(stderr, "START %s status=%d wall_us=%" PRIu64 "\n", label, status, now_us() - before);
    fprintf(stderr, "CATALOG_PREPARE %s seen=%d outcome=%d returned_none=%d work=%" PRIu64 " wall_us=%" PRIu64 " maximum_startup_vm_stage_us=%" PRIu64 "\n", label,
        startup_bounds.prepare_seen, startup_bounds.prepare_outcome, startup_bounds.prepare_none,
        startup_bounds.prepare_work, startup_bounds.prepare_us, startup_bounds.stage_us);
    fprintf(stderr, "PREALLOCATION_BOUND %s arena_limit=%zu arena_used_before_catalog=%zu catalog_heap_allowance=%zu accounted_arena_plus_heap_bound=%zu heap_seen=%d process_metadata_excluded=1 observed_peak_available=%d\n",
        label, startup_bounds.arena_limit, startup_bounds.arena_used, startup_bounds.heap_allowance,
        startup_bounds.arena_used + startup_bounds.heap_allowance, startup_bounds.heap_seen, status == MO_PROTOCOL_SERVER_OK);
    need(startup_bounds.arena_limit == MO_LIMIT_MCP_CATALOG_MEMORY && startup_bounds.heap_seen &&
        startup_bounds.arena_used <= MO_LIMIT_MCP_CATALOG_MEMORY &&
        startup_bounds.heap_allowance <= MO_LIMIT_MCP_CATALOG_MEMORY - startup_bounds.arena_used,
        "catalog preallocation arena and heap bounds recorded");
    if (status == MO_PROTOCOL_SERVER_OK) {
        size_t peak = mo_protocol_server_metrics(f->server).catalog_memory;
        need(peak > 0 && peak <= MO_LIMIT_MCP_CATALOG_MEMORY, "observed catalog peak within catalog allowance");
        fprintf(stderr, "CATALOG_PEAK %s observed_bytes=%zu\n", label, peak);
    }
    return status == MO_PROTOCOL_SERVER_OK;
}
static void finish(struct fixture_server *f) {
    mo_protocol_server_free(f->server); mo_listener_close(f->listener); mo_store_close(f->store);
}
static struct mo_buffer header(size_t length, bool full, bool chunks, bool auth) {
    struct mo_buffer b = buffer();
    add(&b, "POST /mcp HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nMCP-Protocol-Version: 2025-11-25\r\n");
    if (chunks) add(&b, "Transfer-Encoding: chunked\r\n");
    else fmt(&b, "Content-Length: %zu\r\n", length);
    if (auth) fmt(&b, "Authorization: Bearer %s\r\n", token);
    if (full) {
        for (size_t i = 0; i < 58; i++) fmt(&b, "X-%zu: a\r\n", i);
        add(&b, "X-Pad: ");
        MO_ASSERT(b.length + 4 <= MO_LIMIT_MCP_HEADER_BYTES);
        repeat(&b, "a", MO_LIMIT_MCP_HEADER_BYTES - b.length - 4); add(&b, "\r\n");
    }
    add(&b, "\r\n");
    if (full) MO_ASSERT(b.length == MO_LIMIT_MCP_HEADER_BYTES);
    return b;
}
static struct mo_buffer wire(const struct mo_buffer *body, bool full, bool auth) {
    struct mo_buffer b = header(body->length, full, false, auth);
    MO_ASSERT(mo_buffer_append(&b, body->bytes, body->length)); return b;
}
struct result {
    struct mo_protocol_metrics metrics;
    uint64_t wall_us, poll_us, admitted, measured_stage_us;
    size_t polls, input, output;
    int http;
    bool closed, half_closed;
    char *text;
};
static struct result request(struct fixture_server *f, struct mo_buffer *input, size_t quantum) {
    struct result r = {.text = calloc(1, MO_LIMIT_MCP_RESPONSE_BYTES + 4096), .input = input->length};
    MO_ASSERT(r.text != NULL);
    struct mo_listener_fake_peer p = {.input = input->bytes, .input_size = input->length,
        .output = (uint8_t *)r.text, .output_capacity = MO_LIMIT_MCP_RESPONSE_BYTES + 4095,
        .read_quantum = quantum, .write_quantum = 2048, .readable = true, .writable = true, .eof = true};
    uint64_t before = now_us(), admitted = mo_protocol_server_metrics(f->server).admitted;
    MO_ASSERT(mo_listener_fake_connect(f->listener, &p) == MO_LISTENER_OK);
    measured_stage_us = 0; measuring = true;
    size_t ceiling = quantum == 1 ? 2 * input->length + 1024 : input->length / 512 + 4096;
    for (; r.polls < ceiling && !p.closed; r.polls++) {
        uint64_t tick = now_us();
        enum mo_protocol_server_status status = mo_protocol_server_poll(f->server, 0);
        uint64_t elapsed = now_us() - tick;
        if (elapsed > r.poll_us) r.poll_us = elapsed;
        MO_ASSERT(status == MO_PROTOCOL_SERVER_OK);
    }
    measuring = false; r.measured_stage_us = measured_stage_us;
    r.wall_us = now_us() - before; r.metrics = mo_protocol_server_metrics(f->server);
    r.admitted = r.metrics.admitted - admitted; r.output = p.output_size;
    r.closed = p.closed; r.half_closed = p.half_closed;
    (void)sscanf(r.text, "HTTP/1.1 %d", &r.http);
    need(p.closed && p.half_closed, "request closes and half closes");
    return r;
}
static void report(const char *name, struct result *r, int status, int admission, const char *needle) {
    bool semantic = r->http == status && r->admitted == (uint64_t)admission &&
        (needle == NULL || strstr(r->text, needle) != NULL) && r->closed && r->half_closed;
    bool preauth2 = r->metrics.preauth_memory <= MO_LIMIT_MCP_HEADER_HEAP / 2 && r->metrics.preauth_work <= MO_LIMIT_MCP_HEADER_WORK / 2;
    bool request2 = r->metrics.request_memory <= MO_LIMIT_MCP_REQUEST_MEMORY / 2 && r->metrics.work <= MO_LIMIT_MCP_REQUEST_WORK / 2;
    need(semantic, name);
    if (!preauth2 || !request2) headroom_failures++;
    printf("%s\t%d\t%" PRIu64 "\t%zu\t%zu\t%" PRIu64 "\t%" PRIu64 "\t%" PRIu64 "\t%zu\t%" PRIu64 "\t%zu\t%zu\t%zu\t%zu\t%" PRIu64 "\t%zu\t%d\t%d\t%d\t%" PRIu64 "\n",
        name, r->http, r->admitted, r->input, r->output, r->wall_us, r->poll_us,
        r->metrics.work, r->metrics.request_memory, r->metrics.preauth_work,
        r->metrics.preauth_memory, r->metrics.native_memory, r->metrics.concurrent_memory,
        r->metrics.catalog_memory, r->metrics.stage_us, r->polls, semantic, preauth2, request2,
        r->measured_stage_us);
    fflush(stdout);
    if (!semantic) fprintf(stderr, "RESPONSE %s %.800s\n", name, r->text);
}
static void state(struct fixture_server *f, uint64_t value, const char *name) {
    struct mo_buffer body = plain("{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"tools/call\",\"params\":{\"name\":\"read\"}}");
    struct mo_buffer input = wire(&body, false, true); struct result r = request(f, &input, 0);
    char expected[96]; snprintf(expected, sizeof expected, "\"structuredContent\":{\"value\":\"%" PRIu64 "\"}", value);
    bool ok = r.http == 200 && r.admitted == 1 && strstr(r.text, expected) != NULL;
    need(ok, "state oracle"); fprintf(stderr, "STATE %s expected=%" PRIu64 " pass=%d %.350s\n", name, value, ok, ok ? "" : r.text);
    free(r.text); mo_buffer_free(&body); mo_buffer_free(&input);
}
static struct result run(struct mo_image *image, const char *name, struct mo_buffer *body,
                          bool full, bool auth, size_t quantum, int status, int admission,
                          const char *needle, uint64_t expected_state) {
    struct fixture_server f;
    if (!start(&f, image, name)) { need(false, "server startup"); finish(&f); return (struct result){.text = calloc(1, 1)}; }
    struct mo_buffer input = wire(body, full, auth); struct result r = request(&f, &input, quantum);
    report(name, &r, status, admission, needle);
    state(&f, expected_state, name);
    finish(&f); mo_buffer_free(&input); return r;
}

static struct mo_buffer array_call(const char *name, size_t n, bool duplicate) {
    struct mo_buffer b = call_start(name, "value"); add(&b, "[");
    for (size_t i = 0; i < n; i++) {
        if (i) add(&b, ",");
        if (duplicate && i + 1 == n) add(&b, "\"0000\"");
        else fmt(&b, "\"%zu\"", i);
    }
    add(&b, "]"); call_end(&b); return b;
}
static struct mo_buffer map_call(size_t n, bool original, bool duplicate) {
    struct mo_buffer b = call_start("mapints", "value"); add(&b, "[");
    for (size_t i = 0; i < n; i++) {
        if (i) add(&b, ",");
        if (duplicate && i + 1 == n) add(&b, original ? "[\"0\",[\"1\",\"2\",\"3\"]]" : "[\"0000\",[]]");
        else fmt(&b, original ? "[\"%zu\",[\"1\"]]" : "[\"%zu\",[]]", i);
    }
    add(&b, "]"); call_end(&b); return b;
}
static size_t digits(size_t n) {
    size_t count = 1; while (n >= 10) { n /= 10; count++; } return count;
}
static void fitting_duplicate(struct mo_image *image, bool map) {
    const char *tool = map ? "mapints" : "setints";
    const char *name = map ? "map_duplicate_end_max_byte_fit" : "set_duplicate_end_max_byte_fit";
    struct mo_buffer prefix = call_start(tool, "value");
    size_t unique_bytes = 0, count = 0, predicted = 0, next_bytes = 0;
    for (size_t n = 2; n <= 16382; n++) {
        unique_bytes += digits(n - 2) + (map ? 7 : 2);
        size_t bytes = prefix.length + 1 + unique_bytes + (map ? 11 : 6) + n - 1 + 1 + 3;
        if (bytes > MO_LIMIT_MCP_BODY_BYTES) { next_bytes = bytes; break; }
        count = n; predicted = bytes;
    }
    mo_buffer_free(&prefix);
    MO_ASSERT(count >= 2 && next_bytes > MO_LIMIT_MCP_BODY_BYTES);
    struct mo_buffer body = map ? map_call(count, false, true) : array_call(tool, count, true);
    need(body.length == predicted, "duplicate body independently calculated length");
    size_t nodes = map ? 2 + 3 * count : count + 2;
    need(nodes <= MO_LIMIT_MCP_PAYLOAD_NODES, "byte-fitting duplicate stays within payload node ceiling");
    fprintf(stderr, "DUPLICATE %s entries=%zu payload_nodes=%zu unpadded_bytes=%zu next_entry_body_bytes=%zu padded_body_bytes=%u canonical_last_key=0\n",
        name, count, nodes, body.length, next_bytes, (unsigned)MO_LIMIT_MCP_BODY_BYTES);
    repeat(&body, " ", MO_LIMIT_MCP_BODY_BYTES - body.length);
    struct result r = run(image, name, &body, false, true, 0, 200, 0, "invalid_arguments", 0);
    need(strstr(r.text, "work_limit") == NULL, "duplicate rejection must not become work_limit");
    free(r.text); mo_buffer_free(&body);
    body = map ? map_call(count, false, false) : array_call(tool, count, false);
    MO_ASSERT(body.length <= MO_LIMIT_MCP_BODY_BYTES); repeat(&body, " ", MO_LIMIT_MCP_BODY_BYTES - body.length);
    char expected[96]; snprintf(expected, sizeof expected, "\"structuredContent\":{\"value\":\"%zu\"}", count);
    r = run(image, map ? "map_max_byte_fit_unique_control" : "set_max_byte_fit_unique_control",
        &body, false, true, 0, 200, 1, expected, 1);
    free(r.text); mo_buffer_free(&body);
}
static struct mo_buffer escaped_body(size_t limit, size_t *decoded) {
    struct mo_buffer body = call_start("text", "value"); add(&body, "\"");
    MO_ASSERT(limit >= body.length + 4);
    size_t count = (limit - body.length - 4) / 6;
    repeat(&body, "\\u0000", count);
    size_t remainder = limit - body.length - 4; repeat(&body, "x", remainder);
    add(&body, "\""); call_end(&body); MO_ASSERT(body.length == limit);
    *decoded = count + remainder; return body;
}
static const char *response_body(const struct result *r) {
    const char *at = strstr(r->text, "\r\n\r\n"); return at == NULL ? "" : at + 4;
}
static void json_quote(struct mo_buffer *out, const struct mo_buffer *text) {
    add(out, "\"");
    for (size_t i = 0; i < text->length; i++) {
        uint8_t ch = text->bytes[i];
        if (ch == '"' || ch == '\\') { add(out, "\\"); MO_ASSERT(mo_buffer_append(out, &ch, 1)); }
        else if (ch < 32) fmt(out, "\\u%04x", (unsigned)ch);
        else MO_ASSERT(mo_buffer_append(out, &ch, 1));
    }
    add(out, "\"");
}
static struct mo_buffer success_reference(bool many, size_t n) {
    struct mo_buffer content = plain("{\"value\":");
    if (many) {
        add(&content, "[");
        for (size_t i = 0; i < n; i++) { if (i) add(&content, ","); add(&content, "\"0\""); }
        add(&content, "]");
    } else { add(&content, "\""); repeat(&content, "x", n); add(&content, "\""); }
    add(&content, "}");
    struct mo_buffer body = plain("{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{\"content\":[{\"type\":\"text\",\"text\":");
    json_quote(&body, &content); add(&body, "}],\"structuredContent\":");
    MO_ASSERT(mo_buffer_append(&body, content.bytes, content.length)); add(&body, ",\"isError\":false}}");
    mo_buffer_free(&content); return body;
}
static void exact_success(const struct result *r, bool many, size_t n) {
    struct mo_buffer expected = success_reference(many, n);
    const char *actual = response_body(r);
    need(strlen(actual) == expected.length && memcmp(actual, expected.bytes, expected.length) == 0,
        "successful response matches independently serialized reference");
    mo_buffer_free(&expected);
}
static void concurrent(struct mo_image *image, size_t n) {
    struct fixture_server f;
    if (!start(&f, image, "concurrent8")) { need(false, "concurrent server startup"); finish(&f); return; }
    struct mo_buffer body = scalar_call("response", n), input = wire(&body, false, true);
    struct mo_listener_fake_peer peers[8] = {0};
    uint64_t before = now_us(), poll_peak = 0; size_t polls = 0;
    measured_stage_us = 0; measuring = true;
    concurrent_watch = true; concurrent_process_count = 0;
    memset(concurrent_processes, 0, sizeof concurrent_processes);
    for (size_t i = 0; i < 8; i++) {
        peers[i] = (struct mo_listener_fake_peer){.input = input.bytes, .input_size = input.length,
            .output = calloc(1, MO_LIMIT_MCP_RESPONSE_BYTES + 4096), .output_capacity = MO_LIMIT_MCP_RESPONSE_BYTES + 4095,
            .readable = true, .writable = false, .eof = true};
        MO_ASSERT(peers[i].output != NULL);
        MO_ASSERT(mo_listener_fake_connect(f.listener, &peers[i]) == MO_LISTENER_OK);
    }
    for (; polls < 256; polls++) {
        uint64_t tick = now_us(); MO_ASSERT(mo_protocol_server_poll(f.server, 0) == MO_PROTOCOL_SERVER_OK);
        uint64_t elapsed = now_us() - tick; if (elapsed > poll_peak) poll_peak = elapsed;
        if (mo_protocol_server_metrics(f.server).admitted == 8 && polls > 32) break;
    }
    struct mo_protocol_metrics peak = mo_protocol_server_metrics(f.server);
    size_t independently_summed_process_peaks = 0, live = 0;
    for (size_t i = 0; i < concurrent_process_count; i++) {
        if (concurrent_processes[i] != NULL) {
            live++; independently_summed_process_peaks += mo_process_memory_peak(concurrent_processes[i]);
        }
    }
    concurrent_watch = false;
    need(concurrent_process_count == 8 && live == 8 && peak.concurrent_memory >= independently_summed_process_peaks,
        "concurrent metric contains independent sum of eight retained protocol process peaks");
    for (size_t i = 0; i < 8; i++) peers[i].writable = true;
    bool closed = false;
    for (size_t i = 0; i < 4096 && !closed; i++, polls++) {
        uint64_t tick = now_us(); MO_ASSERT(mo_protocol_server_poll(f.server, 0) == MO_PROTOCOL_SERVER_OK);
        uint64_t elapsed = now_us() - tick; if (elapsed > poll_peak) poll_peak = elapsed;
        closed = true; for (size_t j = 0; j < 8; j++) closed = closed && peers[j].closed;
    }
    bool good = closed && peak.admitted == 8; size_t output = 0;
    for (size_t i = 0; i < 8; i++) {
        good = good && peers[i].half_closed && strstr((char *)peers[i].output, "HTTP/1.1 200 ") == (char *)peers[i].output && strstr((char *)peers[i].output, "\"isError\":false") != NULL;
        struct result peer = {.text = (char *)peers[i].output}; exact_success(&peer, false, n);
        output += peers[i].output_size;
    }
    measuring = false;
    struct result r = {.metrics = mo_protocol_server_metrics(f.server), .http = 200, .admitted = peak.admitted,
        .input = 8 * input.length, .output = output, .wall_us = now_us() - before, .poll_us = poll_peak,
        .measured_stage_us = measured_stage_us,
        .polls = polls, .text = "\"isError\":false", .closed = closed, .half_closed = good};
    need(r.metrics.concurrent_memory >= r.metrics.request_memory, "concurrent memory includes one request peak");
    bool aggregate2 = r.metrics.concurrent_memory <= 8 * (MO_LIMIT_MCP_REQUEST_MEMORY / 2);
    if (!aggregate2) headroom_failures++;
    fprintf(stderr, "CONCURRENT measured_aggregate=%zu independently_summed_protocol_process_peaks=%zu single_request_peak=%zu live_processes=%zu peers=8 all_success=%d aggregate_2x=%d\n",
        r.metrics.concurrent_memory, independently_summed_process_peaks, r.metrics.request_memory, live, good, aggregate2);
    report("concurrent8", &r, 200, 8, "\"isError\":false"); state(&f, 8, "concurrent8");
    for (size_t i = 0; i < 8; i++) free(peers[i].output);
    mo_buffer_free(&body); mo_buffer_free(&input); finish(&f);
}

static void chunks(struct mo_image *image) {
    struct mo_buffer body = scalar_call("response", 0);
    repeat(&body, " ", 1024 - body.length);
    struct mo_buffer input = header(0, false, true, true);
    const char *configured = getenv("MO160_CHUNK_BYTES");
    size_t target = configured == NULL ? MO_LIMIT_MCP_INGRESS_BYTES : (size_t)strtoull(configured, NULL, 10);
    MO_ASSERT(target <= MO_LIMIT_MCP_INGRESS_BYTES);
    size_t budget = target - input.length;
    size_t extra = budget - 5 - 1024 * 9;
    for (size_t i = 0; i < 1024; i++) {
        size_t ext = i == 0 ? MO_LIMIT_MCP_LINE_BYTES - 4 : extra / (1024 - i);
        MO_ASSERT(ext <= extra && ext + 4 <= MO_LIMIT_MCP_LINE_BYTES);
        add(&input, "1;x="); repeat(&input, "a", ext); add(&input, "\r\n");
        MO_ASSERT(mo_buffer_append(&input, body.bytes + i, 1)); add(&input, "\r\n"); extra -= ext;
    }
    add(&input, "0\r\n\r\n"); MO_ASSERT(extra == 0 && input.length == target);
    struct fixture_server f;
    fprintf(stderr, "CHUNKS count=1024 body_bytes=%zu total_ingress_including_headers=%zu first_size_line_bytes=%u\n",
        body.length, input.length, (unsigned)MO_LIMIT_MCP_LINE_BYTES);
    if (start(&f, image, "chunks1024_max_ingress_including_headers_line8192")) {
        struct result r = request(&f, &input, 0);
        report("chunks1024_max_ingress_including_headers_line8192", &r, 200, 1, "\"isError\":false");
        exact_success(&r, false, 0);
        state(&f, 1, "chunks1024_max_ingress_including_headers_line8192"); free(r.text);
    } else need(false, "chunk server startup");
    finish(&f); mo_buffer_free(&body); mo_buffer_free(&input);
}

static void graph_add(bool *seen, uint32_t *queue, size_t *count, uint32_t index) {
    if (!seen[index]) { seen[index] = true; queue[(*count)++] = index; }
}
static void graph_stats(struct mo_image *image, bool ceiling) {
    const struct mo_bytecode *file = mo_image_bytecode(image);
    const struct mo_bytecode_service *service = &file->services[0];
    bool *seen = calloc(file->type_count, sizeof *seen);
    uint32_t *queue = calloc(file->type_count, sizeof *queue);
    MO_ASSERT(seen != NULL && queue != NULL);
    size_t count = 0, edges = 0;
    for (uint32_t i = 0; i < service->tool_count; i++) {
        const struct mo_bytecode_service_tool *tool = &service->tools[i];
        MO_ASSERT(tool->read_only);
        graph_add(seen, queue, &count, tool->result_type);
        for (uint32_t j = 0; j < tool->argument_count; j++) graph_add(seen, queue, &count, tool->argument_types[j]);
    }
    for (size_t i = 0; i < count; i++) {
        const struct mo_type *type = &file->types[queue[i]];
        for (uint32_t j = 0; j < type->parameter_count; j++) { edges++; graph_add(seen, queue, &count, type->parameters[j]); }
        for (uint32_t j = 0; j < type->field_count; j++) { edges++; graph_add(seen, queue, &count, type->fields[j].type); }
        for (uint32_t j = 0; j < type->case_count; j++)
            for (uint32_t k = 0; k < type->cases[j].field_count; k++) { edges++; graph_add(seen, queue, &count, type->cases[j].fields[k].type); }
    }
    fprintf(stderr, "GRAPH reachable_nodes=%zu type_edges=%zu tools=%u\n", count, edges, service->tool_count);
    if (ceiling) need(count == 4096 && edges == 16384, "catalog graph exactly at both ceilings");
    free(seen); free(queue);
}
static size_t json_span(const char *start) {
    if (start == NULL || *start != '{') return 0;
    size_t depth = 0; bool quoted = false, escaped = false;
    for (size_t i = 0; start[i] != '\0'; i++) {
        char ch = start[i];
        if (quoted) {
            if (escaped) escaped = false;
            else if (ch == '\\') escaped = true;
            else if (ch == '"') quoted = false;
        } else if (ch == '"') quoted = true;
        else if (ch == '{' || ch == '[') depth++;
        else if (ch == '}' || ch == ']') { if (--depth == 0) return i + 1; }
    }
    return 0;
}
static struct mo_image *catalog_source(unsigned kind) {
    struct mo_buffer b = plain("module Main\n");
    if (kind == 0) {
        for (size_t i = 0; i < 4062; i++) fmt(&b, "struct Leaf%zu\na: Text\nb: Text\nc: Text\nend\n", i);
        size_t leaf = 0;
        for (size_t i = 0; i < 32; i++) {
            fmt(&b, "struct Root%zu\n", i);
            size_t count = i < 30 ? 127 : 126;
            for (size_t j = 0; j < count; j++, leaf++) fmt(&b, "f%zu: Leaf%zu\n", j, leaf);
            size_t extra = i < 8 ? 5 : 4;
            for (size_t j = 0; j < extra; j++) fmt(&b, "x%zu: Text\n", j);
            add(&b, "end\n");
        }
        MO_ASSERT(leaf == 4062);
    }
    if (kind == 2) {
        add(&b, "struct Large\n");
        for (size_t i = 0; i < 6000; i++) fmt(&b, "f%zu: Text\n", i);
        add(&b, "end\n");
    }
    if (kind >= 3) {
        size_t target = kind == 3 ? MO_LIMIT_MCP_SCHEMA_BYTES :
            kind == 4 ? MO_LIMIT_MCP_RESPONSE_BYTES - 1538 :
            kind == 6 ? MO_LIMIT_MCP_RESPONSE_BYTES - 1538 + 1 : kind == 7 ? 1000 : 368;
        size_t base = kind == 6 ? 369 : 368;
        MO_ASSERT(target >= base && (target - base) % 2 == 0);
        size_t padding = (target - base) / 2;
        add(&b, "struct Large\n");
        for (size_t i = 0; i < 4; i++) {
            fmt(&b, "%c", 'a' + (int)i);
            repeat(&b, "a", padding / 4 + (i < padding % 4 ? 1 : 0));
            add(&b, i == 0 && kind != 6 ? ": Text\n" : ": Bool\n");
        }
        add(&b, "end\n");
        fprintf(stderr, "SCHEMA expected_input_bytes=%zu total_added_name_bytes=%zu\n", base + 2 * padding, padding);
    }
    add(&b, "service\nstate Int = 0\ntools ");
    size_t count = kind == 1 || kind == 7 ? 33 : kind == 0 ? 32 : 1;
    for (size_t i = 0; i < count; i++) { if (i) add(&b, ", "); fmt(&b, "tool%zu", i); }
    add(&b, "\ntoken from env \"MO_HEADROOM_TOKEN\"\nend\n");
    for (size_t i = 0; i < count; i++) {
        fmt(&b, "fn tool%zu(_state: Int, _now: Time", i);
        if (kind == 0) fmt(&b, ", _value: Root%zu", i);
        if (kind >= 2) add(&b, ", _value: Large");
        add(&b, ") : Bool\nfalse\nend\n");
    }
    MO_ASSERT(mo_buffer_append(&b, "", 1));
    fprintf(stderr, "COMPILE catalog kind=%u source_bytes=%zu\n", kind, b.length - 1);
    struct fixture preflight; init(&preflight, (char *)b.bytes);
    for (uint32_t i = 0; i < preflight.diags.count; i++) {
        const struct mo_diag *d = &preflight.diags.items[i];
        fprintf(stderr, "CATALOG SOURCE E%04u at=%u %s: %s\n", d->code, d->primary.span.start, d->message, d->reason);
    }
    free_fixture(&preflight);
    struct mo_image *image = compile((char *)b.bytes); mo_buffer_free(&b); return image;
}
static size_t schema_target(unsigned kind) {
    return kind == 3 ? MO_LIMIT_MCP_SCHEMA_BYTES : kind == 4 ? MO_LIMIT_MCP_RESPONSE_BYTES - 1538 :
        kind == 6 ? MO_LIMIT_MCP_RESPONSE_BYTES - 1538 + 1 : kind == 7 ? 1000 : 368;
}
static void schema_name(struct mo_buffer *b, unsigned kind, size_t tool, size_t index) {
    if (kind == 0) {
        size_t leaves = tool < 30 ? 127 : 126;
        fmt(b, "\"%c%zu\"", index < leaves ? 'f' : 'x', index < leaves ? index : index - leaves);
    } else if (kind == 2) fmt(b, "\"f%zu\"", index);
    else {
        size_t padding = (schema_target(kind) - (kind == 6 ? 369 : 368)) / 2;
        fmt(b, "\"%c", 'a' + (int)index);
        repeat(b, "a", padding / 4 + (index < padding % 4 ? 1 : 0)); add(b, "\"");
    }
}
static struct mo_buffer input_schema_reference(unsigned kind, size_t tool) {
    struct mo_buffer b = plain("{\"$schema\":\"https://json-schema.org/draft/2020-12/schema\",\"type\":\"object\",\"properties\":{");
    if (kind == 1) { add(&b, "},\"required\":[],\"additionalProperties\":false}"); return b; }
    add(&b, "\"_value\":{\"$ref\":\"#/$defs/t0\"}},\"required\":[\"_value\"],\"additionalProperties\":false,\"$defs\":{\"t0\":{\"type\":\"object\",\"properties\":{");
    size_t leaves = kind == 0 ? (tool < 30 ? 127 : 126) : 0;
    size_t count = kind == 0 ? leaves + (tool < 8 ? 5 : 4) : kind == 2 ? 6000 : 4;
    for (size_t i = 0; i < count; i++) {
        if (i) { add(&b, ","); }
        schema_name(&b, kind, tool, i); add(&b, ":");
        if (kind == 0 && i < leaves) fmt(&b, "{\"$ref\":\"#/$defs/t%zu\"}", i + 1);
        else add(&b, kind == 0 || kind == 2 || (kind != 6 && i == 0) ? "{\"type\":\"string\"}" : "{\"type\":\"boolean\"}");
    }
    add(&b, "},\"required\":[");
    for (size_t i = 0; i < count; i++) { if (i) add(&b, ","); schema_name(&b, kind, tool, i); }
    add(&b, "],\"additionalProperties\":false}");
    for (size_t i = 0; i < leaves; i++)
        fmt(&b, ",\"t%zu\":{\"type\":\"object\",\"properties\":{\"a\":{\"type\":\"string\"},\"b\":{\"type\":\"string\"},\"c\":{\"type\":\"string\"}},\"required\":[\"a\",\"b\",\"c\"],\"additionalProperties\":false}", i + 1);
    add(&b, "}}"); return b;
}
static const char bool_output_schema[] =
    "{\"$schema\":\"https://json-schema.org/draft/2020-12/schema\",\"type\":\"object\",\"oneOf\":["
    "{\"type\":\"object\",\"properties\":{\"value\":{\"type\":\"boolean\"}},\"required\":[\"value\"],\"additionalProperties\":false},"
    "{\"type\":\"object\",\"properties\":{\"error\":{\"type\":\"object\",\"properties\":{\"kind\":{\"const\":\"runtime\"},\"code\":{\"enum\":["
    "\"invalid_arguments\",\"busy\",\"stopped\",\"memory_limit\",\"work_limit\",\"handler_failed\",\"store_failed\",\"rate_limited\",\"response_limit\",\"internal_error\"]},"
    "\"message\":{\"type\":\"string\"},\"effect\":{\"enum\":[\"none\",\"applied\",\"unknown\"]}},\"required\":[\"kind\",\"code\",\"message\",\"effect\"],\"additionalProperties\":false}},\"required\":[\"error\"],\"additionalProperties\":false}]}";
static struct mo_buffer catalog_page_reference(struct mo_buffer *tools, size_t start, size_t count,
                                              size_t total, const struct mo_buffer *id, uint64_t key) {
    struct mo_buffer b = plain("{\"jsonrpc\":\"2.0\",\"id\":");
    MO_ASSERT(mo_buffer_append(&b, id->bytes, id->length)); add(&b, ",\"result\":{\"tools\":[");
    for (size_t i = 0; i < count; i++) {
        if (i) { add(&b, ","); }
        MO_ASSERT(mo_buffer_append(&b, tools[start + i].bytes, tools[start + i].length));
    }
    add(&b, "]");
    if (start + count < total) fmt(&b, ",\"nextCursor\":\"%zu.%016" PRIx64 "\"", start + count, key);
    add(&b, "}}"); return b;
}
static size_t occurrences(const char *text, const char *needle) {
    size_t count = 0; while ((text = strstr(text, needle)) != NULL) { count++; text += strlen(needle); } return count;
}
static void catalog(unsigned kind) {
    const char *names[] = {"catalog4096nodes16384edges_all_pages", "catalog33tools_all_pages",
        "catalog_schema6000fields_unpageable", "catalog_schema256k_unpageable",
        "catalog_max_wire_fitting_schema", "catalog_schema368bytes_control",
        "catalog_schema_exactly_one_byte_past_wire_budget", "catalog33tools_byte_limited_all_pages"};
    MO_ASSERT(kind < sizeof names / sizeof names[0]); const char *name = names[kind];
    size_t total = kind == 1 || kind == 7 ? 33 : kind == 0 ? 32 : 1;
    struct mo_buffer tools[33] = {0}, worst_id = plain("\"");
    repeat(&worst_id, "\\u0000", 128); add(&worst_id, "\"");
    need(worst_id.length == 770 && strlen(bool_output_schema) == 659, "independent worst-ID and output-schema lengths");
    struct mo_image *image = catalog_source(kind); struct fixture_server f;
    graph_stats(image, kind == 0);
    uint64_t key = mo_image_bytecode(image)->header.checksum;
    bool expected_start = true;
    for (size_t i = 0; i < total; i++) {
        struct mo_buffer schema = input_schema_reference(kind, i);
        if (kind >= 3) need(schema.length == schema_target(kind), "independent input-schema target length");
        tools[i] = buffer(); fmt(&tools[i], "{\"name\":\"tool%zu\",\"description\":\"\",\"inputSchema\":", i);
        MO_ASSERT(mo_buffer_append(&tools[i], schema.bytes, schema.length));
        add(&tools[i], ",\"outputSchema\":"); add(&tools[i], bool_output_schema); add(&tools[i], "}");
        struct mo_buffer one = catalog_page_reference(tools, i, 1, total, &worst_id, key);
        fprintf(stderr, "CATALOG_REFERENCE tool=%zu input_schema_bytes=%zu worst_id_single_tool_page_bytes=%zu response_cap=%u\n",
            i, schema.length, one.length, (unsigned)MO_LIMIT_MCP_RESPONSE_BYTES);
        expected_start = expected_start && schema.length <= MO_LIMIT_MCP_SCHEMA_BYTES && one.length <= MO_LIMIT_MCP_RESPONSE_BYTES;
        mo_buffer_free(&one); mo_buffer_free(&schema);
    }
    bool started = start(&f, image, name); need(started == expected_start, "catalog startup matches independently calculated page admission");
    if (!expected_start) need(startup_bounds.prepare_seen && startup_bounds.prepare_outcome == MO_RETURNED &&
        startup_bounds.prepare_none, "unpageable catalog rejected by returned None, not VM work or memory failure");
    if (!started || !expected_start) {
        printf("%s\tSTARTUP_%s\tEXPECTED_%s\tOBSERVED_PEAK_UNAVAILABLE_%d\n", name,
            started ? "ACCEPTED" : "REJECTED", expected_start ? "ACCEPTED" : "REJECTED", !started);
        fprintf(stderr, "CATALOG_STARTUP %s expected_start=%d observed_start=%d request_admission=none reason=single_tool_worst_ID_page_byte_budget\n",
            name, expected_start, started);
    } else {
        struct mo_buffer id = kind == 4 ? plain("\"") : plain("1");
        if (kind == 4) { repeat(&id, "\\u0000", 128); add(&id, "\""); }
        size_t collected = 0, pages = 0; bool seen[33] = {0}; char cursor[80] = "";
        while (collected < total && pages < total) {
            size_t count = 0;
            for (size_t candidate = 1; candidate <= MO_LIMIT_MCP_PAGE_TOOLS && collected + candidate <= total; candidate++) {
                struct mo_buffer trial = catalog_page_reference(tools, collected, candidate, total, &id, key);
                bool fits = trial.length <= MO_LIMIT_MCP_RESPONSE_BYTES; mo_buffer_free(&trial);
                if (!fits) { break; }
                count = candidate;
            }
            need(count != 0, "at least one catalog tool independently fits"); if (count == 0) break;
            struct mo_buffer expected = catalog_page_reference(tools, collected, count, total, &id, key);
            struct mo_buffer body = plain("{\"jsonrpc\":\"2.0\",\"id\":");
            MO_ASSERT(mo_buffer_append(&body, id.bytes, id.length)); add(&body, ",\"method\":\"tools/list\"");
            if (cursor[0] != '\0') fmt(&body, ",\"params\":{\"cursor\":\"%s\"}", cursor);
            add(&body, "}"); struct mo_buffer input = wire(&body, false, true);
            char label[128]; snprintf(label, sizeof label, "%s_page%zu", name, pages + 1);
            struct result r = request(&f, &input, 0); report(label, &r, 200, 0, "\"inputSchema\"");
            const char *actual = response_body(&r);
            need(strlen(actual) == expected.length && memcmp(actual, expected.bytes, expected.length) == 0,
                "catalog page exactly matches independent schemas, names, cursor, and byte budget");
            need(occurrences(actual, "\"inputSchema\":") == count, "catalog page independent greedy count");
            for (size_t i = collected; i < collected + count; i++) {
                char tool_name[64]; snprintf(tool_name, sizeof tool_name, "\"name\":\"tool%zu\"", i);
                bool present = !seen[i] && occurrences(actual, tool_name) == 1;
                need(present, "each catalog tool collected exactly once"); if (present) seen[i] = true;
            }
            const char *input_at = strstr(actual, "\"inputSchema\":");
            const char *output_at = strstr(actual, "\"outputSchema\":");
            fprintf(stderr, "PAGE %s start=%zu count=%zu expected_body_bytes=%zu actual_body_bytes=%zu first_input_schema_bytes=%zu first_output_schema_bytes=%zu\n",
                label, collected, count, expected.length, strlen(actual),
                input_at == NULL ? 0 : json_span(input_at + 14), output_at == NULL ? 0 : json_span(output_at + 15));
            if (kind == 4) need(expected.length == MO_LIMIT_MCP_RESPONSE_BYTES && strlen(actual) == expected.length,
                "largest fitting schema with worst ID fills response cap exactly");
            collected += count; pages++;
            const char *next = strstr(actual, "\"nextCursor\":\""); bool follow = true;
            if (collected < total) {
                char wanted[80]; snprintf(wanted, sizeof wanted, "%zu.%016" PRIx64, collected, key);
                if (next == NULL) follow = false;
                else {
                    next += strlen("\"nextCursor\":\""); const char *end = strchr(next, '"');
                    if (end == NULL || (size_t)(end - next) >= sizeof cursor) follow = false;
                    else { memcpy(cursor, next, (size_t)(end - next)); cursor[end - next] = '\0'; follow = strcmp(cursor, wanted) == 0; }
                }
                need(follow, "follow actual returned cursor with independent image key and next index");
            } else need(next == NULL, "last catalog page has no next cursor");
            free(r.text); mo_buffer_free(&body); mo_buffer_free(&input); mo_buffer_free(&expected);
            if (!follow) break;
        }
        size_t unique = 0; for (size_t i = 0; i < total; i++) if (seen[i]) unique++;
        need(collected == total && unique == total && mo_protocol_server_metrics(f.server).admitted == 0,
            "all catalog pages collected without service admission");
        fprintf(stderr, "CATALOG_COMPLETE %s pages=%zu collected=%zu unique=%zu expected=%zu\n", name, pages, collected, unique, total);
        mo_buffer_free(&id);
    }
    finish(&f); mo_image_free(image); mo_buffer_free(&worst_id);
    for (size_t i = 0; i < total; i++) mo_buffer_free(&tools[i]);
}

static void measurements(void *context) {
    const char *only = context;
    memset(token, 'T', 256); token[256] = '\0'; MO_ASSERT(setenv("MO_HEADROOM_TOKEN", token, 1) == 0);
    printf("case\thttp\tadmitted\tingress_bytes\toutput_bytes\twall_us\tmax_poll_us\twork\trequest_memory\tpreauth_work\tpreauth_memory\tnative_memory\tconcurrent_memory\tcatalog_memory\tstage_us\tpolls\tsemantic_ok\tpreauth_2x\trequest_2x\tmeasured_vm_or_service_stage_us\n");
    if (only != NULL && strncmp(only, "catalog", 7) == 0) {
        catalog((unsigned)strtoul(only + 7, NULL, 10)); return;
    }
    struct fixture preflight; init(&preflight, source);
    for (uint32_t i = 0; i < preflight.diags.count; i++) {
        const struct mo_diag *d = &preflight.diags.items[i];
        fprintf(stderr, "SOURCE E%04u at=%u %s: %s\n", d->code, d->primary.span.start, d->message, d->reason);
    }
    free_fixture(&preflight);
    struct mo_image *image = compile(source); struct mo_buffer b; struct result r;
    if (only != NULL && strcmp(only, "chunks") == 0) {
        chunks(image); mo_image_free(image); return;
    }
    fprintf(stderr, "LIMITS header=%u fields=%u token=%u body=%u ingress=%u response=%u preauth_memory=%u preauth_work=%" PRIu64 " request_memory=%u request_work=%" PRIu64 " catalog_memory=%u\n",
        (unsigned)MO_LIMIT_MCP_HEADER_BYTES, (unsigned)MO_LIMIT_MCP_HEADER_FIELDS, (unsigned)MO_LIMIT_MCP_TOKEN_BYTES,
        (unsigned)MO_LIMIT_MCP_BODY_BYTES, (unsigned)MO_LIMIT_MCP_INGRESS_BYTES, (unsigned)MO_LIMIT_MCP_RESPONSE_BYTES,
        (unsigned)MO_LIMIT_MCP_HEADER_HEAP, MO_LIMIT_MCP_HEADER_WORK, (unsigned)MO_LIMIT_MCP_REQUEST_MEMORY,
        MO_LIMIT_MCP_REQUEST_WORK, (unsigned)MO_LIMIT_MCP_CATALOG_MEMORY);
    b = plain("{\"jsonrpc\":\"2.0\",\"id\":1,\"method\":\"ping\"}");
    r = run(image, "header1024_fields64_token256_bytewise", &b, true, true, 1, 200, 0, "\"result\":{}", 0); free(r.text);
    r = run(image, "header1024_fields64_token256_bulk", &b, true, true, 0, 200, 0, "\"result\":{}", 0); free(r.text);
    r = run(image, "unauthenticated", &b, false, false, 0, 401, 0, "WWW-Authenticate: Bearer", 0); free(r.text); mo_buffer_free(&b);
    b = call_start("listints", "value"); add(&b, "["); repeat(&b, "0,", 131000); add(&b, "0]"); call_end(&b);
    MO_ASSERT(b.length <= (256u << 10)); repeat(&b, " ", (256u << 10) - b.length);
    r = run(image, "original_minimal_values256k_rejected_body_byte_ceiling", &b, false, true, 0, 413, 0, NULL, 0); free(r.text); mo_buffer_free(&b);
    for (size_t n = 16382; n <= 16383; n++) {
        b = array_call("listints", n, false);
        MO_ASSERT(b.length > MO_LIMIT_MCP_BODY_BYTES);
        r = run(image, n == 16382 ? "original_payload_nodes16384_rejected_body_byte_ceiling" :
            "original_payload_nodes16385_rejected_body_byte_ceiling", &b, false, true, 0, 413, 0, NULL, 0);
        free(r.text); mo_buffer_free(&b);
    }
    size_t decoded; b = escaped_body(256u << 10, &decoded);
    r = run(image, "original_worst_escapes256k_rejected_body_byte_ceiling", &b, false, true, 0, 413, 0, NULL, 0); free(r.text); mo_buffer_free(&b);
    b = escaped_body(MO_LIMIT_MCP_BODY_BYTES, &decoded);
    char escaped_value[96]; snprintf(escaped_value, sizeof escaped_value, "\"structuredContent\":{\"value\":\"%zu\"}", decoded);
    fprintf(stderr, "ESCAPES exact_body_bytes=%zu decoded_value_bytes=%zu\n", b.length, decoded);
    r = run(image, "worst_escapes_exact_body_limit16k", &b, false, true, 0, 200, 1, escaped_value, 1); free(r.text);
    r = run(image, "worst_escapes_body16k_bytewise", &b, false, true, 1, 200, 1, escaped_value, 1); free(r.text);
    r = run(image, "worst_escapes_body16k_twobyte", &b, false, true, 2, 200, 1, escaped_value, 1); free(r.text); mo_buffer_free(&b);
    b = call_start("text", "value"); add(&b, "\"");
    decoded = MO_LIMIT_MCP_BODY_BYTES - b.length - 4;
    repeat(&b, "x", decoded); add(&b, "\""); call_end(&b);
    MO_ASSERT(b.length == MO_LIMIT_MCP_BODY_BYTES);
    snprintf(escaped_value, sizeof escaped_value, "\"structuredContent\":{\"value\":\"%zu\"}", decoded);
    r = run(image, "plain_body16k_bytewise", &b, false, true, 1, 200, 1, escaped_value, 1); free(r.text);
    r = run(image, "plain_body16k_twobyte", &b, false, true, 2, 200, 1, escaped_value, 1); free(r.text); mo_buffer_free(&b);
    for (size_t depth = 60; depth <= 61; depth++) {
        b = call_start("chain", "_value"); repeat(&b, "{\"case\":\"Next\",\"value\":", depth - 1);
        add(&b, "{\"case\":\"Done\"}"); repeat(&b, "}", depth - 1); call_end(&b);
        r = run(image, depth == 60 ? "value_depth60" : "value_depth61", &b, false, true, 0, 200, depth == 60 ? 1 : 0,
            depth == 60 ? "\"isError\":false" : "invalid_arguments", depth == 60 ? 1 : 0);
        free(r.text); mo_buffer_free(&b);
    }
    b = array_call("setints", 16382, true);
    MO_ASSERT(b.length > MO_LIMIT_MCP_BODY_BYTES);
    r = run(image, "original_set_duplicate_end_nodes16384_rejected_body_byte_ceiling", &b, false, true, 0, 413, 0, NULL, 0); free(r.text); mo_buffer_free(&b);
    b = map_call(4095, true, true); MO_ASSERT(b.length > MO_LIMIT_MCP_BODY_BYTES);
    r = run(image, "original_map_duplicate_end_nodes16384_rejected_body_byte_ceiling", &b, false, true, 0, 413, 0, NULL, 0); free(r.text); mo_buffer_free(&b);
    fitting_duplicate(image, false); fitting_duplicate(image, true);
    b = scalar_call("response", 0);
    r = run(image, "response_text_empty_baseline", &b, false, true, 0, 200, 1, "\"isError\":false", 1);
    exact_success(&r, false, 0); struct mo_buffer baseline = success_reference(false, 0);
    size_t overhead = baseline.length; need(overhead == 138, "independent empty Text response baseline is 138 bytes");
    mo_buffer_free(&baseline); free(r.text); mo_buffer_free(&b);
    size_t max = (MO_LIMIT_MCP_RESPONSE_BYTES - overhead) / 2;
    fprintf(stderr, "RESPONSE_TEXT overhead=%zu maximum_plain_chars=%zu expected_wire_body_bytes=%zu one_past_wire_body_bytes=%zu\n",
        overhead, max, overhead + 2 * max, overhead + 2 * (max + 1));
    size_t sizes[] = {max, max + 1, MO_LIMIT_MCP_RESPONSE_BYTES};
    const char *names[] = {"response_text_max_wire_fit", "response_text_one_past_wire_fit", "response_returned_text32k_fallback"};
    for (size_t i = 0; i < 3; i++) {
        b = scalar_call("response", sizes[i]); r = run(image, names[i], &b, false, true, 0, 200, 1, i == 0 ? "\"isError\":false" : "response_limit", 1);
        if (i == 0) exact_success(&r, false, sizes[i]);
        else need(strstr(r.text, "\"effect\":\"applied\"") != NULL, "oversized Text fallback records applied state");
        free(r.text); mo_buffer_free(&b);
    }
    b = scalar_call("escaped", MO_LIMIT_MCP_RESPONSE_BYTES);
    r = run(image, "response_returned_nul_text32k_fallback", &b, false, true, 0, 200, 1, "response_limit", 1);
    need(strstr(r.text, "\"effect\":\"applied\"") != NULL, "oversized NUL Text fallback records applied state"); free(r.text); mo_buffer_free(&b);
    b = scalar_call("many", 0); r = run(image, "response_many_empty_baseline", &b, false, true, 0, 200, 1, "\"isError\":false", 1);
    exact_success(&r, true, 0); baseline = success_reference(true, 0); size_t many_overhead = baseline.length;
    need(many_overhead == 136, "independent empty List response baseline is 136 bytes");
    mo_buffer_free(&baseline); free(r.text); mo_buffer_free(&b);
    size_t many_max = (MO_LIMIT_MCP_RESPONSE_BYTES - many_overhead + 2) / 10;
    fprintf(stderr, "RESPONSE_MANY empty_overhead=%zu maximum_elements=%zu maximum_native_nodes=%zu expected_wire_body_bytes=%zu one_past_wire_body_bytes=%zu\n",
        many_overhead, many_max, many_max + 1, many_overhead - 2 + 10 * many_max, many_overhead - 2 + 10 * (many_max + 1));
    size_t many_sizes[] = {many_max, many_max + 1, 16383};
    const char *many_names[] = {"response_many_max_wire_fit", "response_many_one_past_wire_fit", "response_former_native_nodes16384_fallback"};
    for (size_t i = 0; i < 3; i++) {
        b = scalar_call("many", many_sizes[i]); r = run(image, many_names[i], &b, false, true, 0, 200, 1, i == 0 ? "\"isError\":false" : "response_limit", 1);
        if (i == 0) exact_success(&r, true, many_sizes[i]);
        else need(strstr(r.text, "\"effect\":\"applied\"") != NULL, "oversized List fallback records applied state");
        free(r.text); mo_buffer_free(&b);
    }
    chunks(image); concurrent(image, max); mo_image_free(image);
}
int main(int argc, char **argv) {
    setvbuf(stdout, NULL, _IOLBF, 0); setvbuf(stderr, NULL, _IOLBF, 0);
    MO_ASSERT(mo_with_stack(MO_SOURCE_STACK_SIZE, measurements, argc > 1 ? argv[1] : NULL) == 0);
    fprintf(stderr, "SEMANTIC_FAILURES %u HEADROOM_FAILURES %u\n", failures, headroom_failures);
    return failures == 0 && headroom_failures == 0 ? 0 : 1;
}
