module Main
service
state Int = 0
tools add, read, reject, fail, large, grow, work, t00, t01, t02, t03, t04, t05, t06, t07, t08, t09, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21, t22, t23, t24, t25
token from env "MO_INTEROP_TOKEN"
end
fn add(state: Int, _now: Time, amount: Int) : (Int, Int)
(state + amount, state + amount)
end
fn read(state: Int, _now: Time) : Text
state.to_text
end
fn reject(_state: Int, _now: Time) : Result(Text, Text)
Error("denied")
end
fn fail(_state: Int, _now: Time) : Text
stop "canary must not leave server"
end
fn large(_state: Int, _now: Time) : Text
"x".repeat(32768)
end
fn grow(state: Int, _now: Time) : (Int, Text)
(state + 1, "x".repeat(32768))
end
fn work(state: Int, now: Time) : (Int, Int)
work(state + 1, now)
end
fn t00(state: Int, _now: Time) : Text
state.to_text
end
fn t01(state: Int, _now: Time) : Text
state.to_text
end
fn t02(state: Int, _now: Time) : Text
state.to_text
end
fn t03(state: Int, _now: Time) : Text
state.to_text
end
fn t04(state: Int, _now: Time) : Text
state.to_text
end
fn t05(state: Int, _now: Time) : Text
state.to_text
end
fn t06(state: Int, _now: Time) : Text
state.to_text
end
fn t07(state: Int, _now: Time) : Text
state.to_text
end
fn t08(state: Int, _now: Time) : Text
state.to_text
end
fn t09(state: Int, _now: Time) : Text
state.to_text
end
fn t10(state: Int, _now: Time) : Text
state.to_text
end
fn t11(state: Int, _now: Time) : Text
state.to_text
end
fn t12(state: Int, _now: Time) : Text
state.to_text
end
fn t13(state: Int, _now: Time) : Text
state.to_text
end
fn t14(state: Int, _now: Time) : Text
state.to_text
end
fn t15(state: Int, _now: Time) : Text
state.to_text
end
fn t16(state: Int, _now: Time) : Text
state.to_text
end
fn t17(state: Int, _now: Time) : Text
state.to_text
end
fn t18(state: Int, _now: Time) : Text
state.to_text
end
fn t19(state: Int, _now: Time) : Text
state.to_text
end
fn t20(state: Int, _now: Time) : Text
state.to_text
end
fn t21(state: Int, _now: Time) : Text
state.to_text
end
fn t22(state: Int, _now: Time) : Text
state.to_text
end
fn t23(state: Int, _now: Time) : Text
state.to_text
end
fn t24(state: Int, _now: Time) : Text
state.to_text
end
fn t25(state: Int, _now: Time) : Text
state.to_text
end
