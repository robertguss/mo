import sys,os,json,socket,subprocess,time,threading,http.server,traceback
from pathlib import Path
sys.path.insert(0,'/tmp/mo160-validation-deps')
from jsonschema import Draft202012Validator
P=Path('/tmp/mo160-evidence'); token=(P/'token').read_bytes(); rows=[]; calls=[]; tools={}; service=None; proxy=None

def compact(x): return json.dumps(x,separators=(',',':')).encode()
def nodes(x): return 1+sum(nodes(v) for v in (x.values() if isinstance(x,dict) else x if isinstance(x,list) else []))
def exchange(raw,label,kind='SYNTHETIC'):
    with socket.create_connection(('127.0.0.1',port),timeout=15) as sock:
        sock.sendall(raw); data=b''
        while True:
            try: chunk=sock.recv(65536)
            except ConnectionResetError: break
            if not chunk: break
            data+=chunk
    n=len(list(P.glob('*.request.http')))
    stem=f'{n:03}-{label}'
    (P/(stem+'.request.http')).write_bytes(raw.replace(token,b'*'*len(token)))
    (P/(stem+'.response.http')).write_bytes(data)
    status=int(data.split(b' ')[1]); body=data.split(b'\r\n\r\n',1)[1]
    obj=json.loads(body) if body else None
    reqbody=raw.split(b'\r\n\r\n',1)[1]
    try: request=json.loads(reqbody)
    except Exception: request=None
    row=dict(case=label,kind=kind,status=status,request_bytes=len(raw),body_bytes=len(reqbody),response_body_bytes=len(body),request=request,response=obj)
    rows.append(row); (P/'captures.json').write_text(json.dumps(rows,indent=2))
    return row

def header(body=b'',auth=None,chunked=False):
    return (b'POST /mcp HTTP/1.1\r\nHost: 127.0.0.1:'+str(port).encode()+b'\r\nAuthorization: Bearer '+(token if auth is None else auth)+b'\r\nMCP-Protocol-Version: 2025-11-25\r\nContent-Type: application/json\r\nAccept: application/json, text/event-stream\r\n'+(b'Transfer-Encoding: chunked' if chunked else b'Content-Length: '+str(len(body)).encode())+b'\r\n\r\n')
def rpc(method,params=None,id=1,label=None):
    req={'jsonrpc':'2.0','id':id,'method':method}
    if params is not None: req['params']=params
    b=compact(req); return exchange(header(b)+b,label or method.replace('/','-'))
def check(row,status,predicate=lambda r:True):
    row['expected_status']=status; row['pass']=row['status']==status and predicate(row)
    if not row['pass']: raise AssertionError(row['case']+': '+json.dumps(row))
    return row

def call(name,args={},id=1):
    r=rpc('tools/call',{'name':name,'arguments':args},id,label=name)
    check(r,200); result=r['response']['result']
    Draft202012Validator(tools[name]['inputSchema']).validate(args)
    Draft202012Validator(tools[name]['outputSchema']).validate(result['structuredContent'])
    assert json.loads(''.join(c['text'] for c in result['content']))==result['structuredContent']
    calls.append(dict(tool=name,schema_valid=True,text_matches=True))
    return result

class Proxy(http.server.BaseHTTPRequestHandler):
    def do_POST(self): self.forward()
    def do_GET(self): self.forward()
    def do_DELETE(self): self.forward()
    def log_message(self,*args): pass
    def forward(self):
        body=self.rfile.read(int(self.headers.get('Content-Length','0')))
        raw=f'{self.command} {self.path} HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\n'.encode()
        for k,v in self.headers.items():
            if k.lower() not in ('host','connection'): raw+=f'{k}: {v}\r\n'.encode()
        raw+=b'Connection: close\r\n\r\n'+body
        r=exchange(raw,'claude-'+self.command,'REAL Claude Code')
        self.send_response(r['status']); self.send_header('Content-Type','application/json'); b=compact(r['response']) if r['response'] else b''
        self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b)

try:
    env=os.environ.copy(); env['MO_INTEROP_TOKEN']=token.decode()
    service=subprocess.Popen([str(P/'socket')],env=env,stdout=(P/'service.log').open('w'),stderr=subprocess.STDOUT)
    for _ in range(200):
        if (P/'port').exists(): break
        if service.poll() is not None: raise RuntimeError('service failed to start')
        time.sleep(.05)
    port=int((P/'port').read_text())
    proxy=http.server.ThreadingHTTPServer(('127.0.0.1',0),Proxy); proxy_port=proxy.server_port
    threading.Thread(target=proxy.serve_forever,daemon=True).start()
    config=P/'claude-config.json'; config.touch(mode=0o600); config.chmod(0o600)
    config.write_text(json.dumps({'mcpServers':{'mo160':{'type':'http','url':f'http://127.0.0.1:{proxy_port}/mcp','headers':{'Authorization':'Bearer '+token.decode()}}}}))
    cmd=['claude','-p','List the tools from mo160, then call its read tool once and report the returned value. Do not use any other tools.','--mcp-config',str(config),'--strict-mcp-config','--tools','','--allowedTools','mcp__mo160__read','--no-session-persistence','--disable-slash-commands','--output-format','json']
    try:
        c=subprocess.run(cmd,cwd=P,capture_output=True,timeout=60)
        (P/'claude.stdout').write_bytes(c.stdout.replace(token,b'[REDACTED]')); (P/'claude.stderr').write_bytes(c.stderr.replace(token,b'[REDACTED]'))
        (P/'claude-exit.txt').write_text(str(c.returncode))
    except subprocess.TimeoutExpired as e:
        (P/'claude-exit.txt').write_text('timeout 60s'); (P/'claude.stdout').write_bytes((e.stdout or b'').replace(token,b'[REDACTED]')); (P/'claude.stderr').write_bytes((e.stderr or b'').replace(token,b'[REDACTED]'))
    config.unlink()
    print('Claude attempt complete',flush=True)
    check(rpc('initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'SYNTHETIC','version':'1'}}),200,lambda r:r['response']['result']['protocolVersion']=='2025-11-25')
    page=check(rpc('tools/list'),200); first=page['response']['result']; assert len(first['tools'])==32
    page2=check(rpc('tools/list',{'cursor':first['nextCursor']},label='tools-list-page2'),200); second=page2['response']['result']; assert len(second['tools'])==1 and 'nextCursor' not in second
    tools={t['name']:t for t in first['tools']+second['tools']}; assert len(tools)==33
    for tool in tools.values():
        Draft202012Validator.check_schema(tool['inputSchema']); Draft202012Validator.check_schema(tool['outputSchema'])
    before=call('read')['structuredContent']['value']; assert call('add',{'amount':'7'})['structuredContent']=={'value':str(int(before)+7)}
    assert call('read')['structuredContent']=={'value':str(int(before)+7)}
    r=call('reject'); assert r['isError'] and r['structuredContent']=={'error':{'kind':'application','value':'denied'}}
    r=call('fail'); assert r['structuredContent']['error']['code']=='handler_failed' and 'canary' not in json.dumps(r)
    assert call('read')['structuredContent']=={'value':str(int(before)+7)}
    for name,effect,code in [('large','none','response_limit'),('grow','applied','response_limit'),('work','none','work_limit')]:
        r=call(name,id='\x00'*128); assert r['isError'] and r['structuredContent']['error']['code']==code and r['structuredContent']['error']['effect']==effect
    assert call('read')['structuredContent']=={'value':str(int(before)+8)}
    b=compact({'jsonrpc':'2.0','id':1,'method':'tools/list'})
    check(exchange(header(b,auth=b'invalid-token')+b,'bad-token'),401,lambda r:r['response'] is None)
    for size in (1024,1025):
        h=header(b); h=h[:-2]+b'X-Pad: '+b'a'*(size-len(h)-9)+b'\r\n\r\n'; assert len(h)==size
        check(exchange(h+b,f'header-{size}'),200 if size==1024 else 431)
    for size in (16384,16385):
        body=b+b' '*(size-len(b)); check(exchange(header(body)+body,f'body-{size}'),200 if size==16384 else 413)
    for size in (24576,24577):
        body=b+b' '*(1024-len(b)); h=header(chunked=True); extra=size-len(h)-5-1024*9; data=h
        for i in range(1024):
            ext=extra//(1024-i); data+=b'1;x='+b'a'*ext+b'\r\n'+body[i:i+1]+b'\r\n'; extra-=ext
        data+=b'0\r\n\r\n'; assert len(data)==size
        check(exchange(data,f'ingress-{size}'),200 if size==24576 else 413)
    (P/'validation.json').write_text(json.dumps({'synthetic':'SYNTHETIC Python controls; not real-client acceptance','schemas_validated':66,'calls':calls,'all_pass':True},indent=2))
    print('SYNTHETIC controls passed',flush=True)
except Exception:
    (P/'failure.txt').write_text(traceback.format_exc()); raise
finally:
    if proxy: proxy.shutdown(); proxy.server_close()
    if service:
        service.terminate()
        try: service.wait(timeout=5)
        except subprocess.TimeoutExpired: service.kill(); service.wait()
    for name in ('token','claude-config.json'):
        (P/name).unlink(missing_ok=True)
    cleanup={'token_deleted':not (P/'token').exists(),'service_exit':service.returncode if service else None}
    for name,value in [('native',locals().get('port')),('proxy',locals().get('proxy_port'))]:
        if value:
            with socket.socket() as s: cleanup[name+'_port_closed']=s.connect_ex(('127.0.0.1',value))!=0
    (P/'cleanup.json').write_text(json.dumps(cleanup,indent=2))
    for f in P.rglob('*'):
        if f.is_file() and f.name!='socket':
            assert token not in f.read_bytes(),f'Secret remains in {f.name}'
    (P/'secret-scan.txt').write_text('PASS: disposable token absent from all evidence files; binary excluded from scan/archive.\n')
    (P/'captures.json').write_text(json.dumps(rows,indent=2))
