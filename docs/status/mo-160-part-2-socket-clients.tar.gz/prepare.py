from pathlib import Path
import json,secrets,os
p=Path('/tmp/mo160-evidence')
t=p/'token'; t.touch(mode=0o600); t.chmod(0o600); t.write_text(secrets.token_hex(32))
s=Path('/tmp/mo160-handoff/mo160-live.c').read_text()
start=s.index('  const char source[] ='); end=s.index('  struct mo_image *image',start)
names=['add','read','reject','fail','large','grow','work']+[f't{i:02}' for i in range(26)]
source='module Main\nservice\nstate Int = 0\ntools '+', '.join(names)+'\ntoken from env "MO_INTEROP_TOKEN"\nend\n'
source+='fn add(state: Int, _now: Time, amount: Int) : (Int, Int)\n(state + amount, state + amount)\nend\nfn read(state: Int, _now: Time) : Text\nstate.to_text\nend\nfn reject(_state: Int, _now: Time) : Result(Text, Text)\nError("denied")\nend\nfn fail(_state: Int, _now: Time) : Text\nstop "canary must not leave server"\nend\nfn large(_state: Int, _now: Time) : Text\n"x".repeat(32768)\nend\nfn grow(state: Int, _now: Time) : (Int, Text)\n(state + 1, "x".repeat(32768))\nend\nfn work(state: Int, now: Time) : (Int, Int)\nwork(state + 1, now)\nend\n'
for name in names[7:]: source+=f'fn {name}(state: Int, _now: Time) : Text\nstate.to_text\nend\n'
s=s[:start]+'  const char source[] = '+json.dumps(source)+';\n'+s[end:]
s=s.replace('/tmp/mo160-live-port',str(p/'port'))
(p/'mo160-socket.c').write_text(s)
(p/'service.mo').write_text(source)
