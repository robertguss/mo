#!/bin/bash
set -euo pipefail
root=/home/exedev/.t3/worktrees/mo/mo-160-part-2
mapfile -t objects < <(find "$root/build/mo160-socket/debug/src" -name '*.o' ! -name main.o | sort)
gcc -std=c17 -O2 -g -pthread -Wall -Wextra -Werror -I"$root/src" -I"$root/tests" -I"$root/build/generated" -I"$root/vendor/sqlite" /tmp/mo160-evidence/mo160-socket.c "${objects[@]}" "$root/build/mo160-socket/debug/vendor/sqlite/sqlite3.o" -lm -o /tmp/mo160-evidence/socket
