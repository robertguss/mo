import json,sys,importlib.metadata,collections
from pathlib import Path
sys.path.insert(0,'/tmp/mo160-validation-deps')
from jsonschema import Draft202012Validator
p=Path('/tmp/mo160-evidence')
rows=json.loads((p/'captures.json').read_text())
def nodes(x): return 1+sum(nodes(v) for v in (x.values() if isinstance(x,dict) else x if isinstance(x,list) else []))
real=[r for r in rows if r['kind']=='REAL Claude Code']
catalog=[r['response']['result']['tools'] for r in real if r.get('request') and r['request']['method']=='tools/list']
assert list(map(len,catalog))==[32,1]
tools={t['name']:t for page in catalog for t in page}; assert len(tools)==33
for tool in tools.values():
    Draft202012Validator.check_schema(tool['inputSchema']); Draft202012Validator.check_schema(tool['outputSchema'])
calls=[]
for r in rows:
    req=r.get('request')
    if not req or req['method']!='tools/call': continue
    assert r['status']==200
    result=r['response']['result']; name=req['params']['name']
    Draft202012Validator(tools[name]['inputSchema']).validate(req['params']['arguments'])
    Draft202012Validator(tools[name]['outputSchema']).validate(result['structuredContent'])
    assert json.loads(''.join(b['text'] for b in result['content'] if b['type']=='text'))==result['structuredContent']
    assert r['response']['id']==req['id']
    calls.append({'kind':r['kind'],'tool':name,'structuredContent':result['structuredContent'],'schema_valid':True,'text_matches':True})
init=next(r for r in real if r.get('request') and r['request']['method']=='initialize')
assert init['body_bytes']==391
assert init['response']['result']['protocolVersion']=='2025-11-25'
assert (p/'claude-exit.txt').read_text()=='0'
cli=json.loads((p/'claude.stdout').read_text()); assert not cli['is_error'] and cli['terminal_reason']=='completed' and not cli['permission_denials']
assert sum(c['kind']=='REAL Claude Code' for c in calls)==1
assert all(r.get('pass',True) for r in rows)
summary={'validator':'jsonschema '+importlib.metadata.version('jsonschema')+' Draft202012Validator','source':'adapted archived-client-summary.py; old Amp-specific assertions replaced with current Claude captures','real_client':'Claude Code 2.1.314','initialize_bytes':init['body_bytes'],'initialize_nodes_keys_excluded':nodes(init['request']),'initialize_nodes_including_keys':nodes(init['request'])+sum(len(x) for x in []),'protocolVersion':init['response']['result']['protocolVersion'],'catalog_pages':[32,1],'schemas_validated':66,'calls':calls,'synthetic_label':'SYNTHETIC Python controls are not real-client acceptance','real_http_counts':dict(collections.Counter(r['status'] for r in real)),'all_pass':True}
def keys(x): return (len(x)+sum(keys(v) for v in x.values())) if isinstance(x,dict) else sum(keys(v) for v in x) if isinstance(x,list) else 0
summary['initialize_nodes_including_keys']=nodes(init['request'])+keys(init['request'])
(p/'client-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
